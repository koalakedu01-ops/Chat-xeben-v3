
CHAT XEBEN PWA + IA

1. Mettre le dossier public sur un hébergement HTTPS.
2. Ajouter le serveur IA avec la route /api/chat.
3. Ouvrir le site sur Android Chrome.
4. Menu > Ajouter à l'écran d'accueil.

Cette base permet de transformer Chat Xeben en application installable.
