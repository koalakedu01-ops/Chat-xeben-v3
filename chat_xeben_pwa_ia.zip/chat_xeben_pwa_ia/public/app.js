
const chat=document.querySelector('#chat');
function add(t,c=''){chat.innerHTML+=`<div class="msg ${c}">${t}</div>`;chat.scrollTop=chat.scrollHeight}
add('Salut 👋 Je suis Chat Xeben.');
async function send(){
 const i=document.querySelector('#text');
 if(!i.value)return;
 const m=i.value;i.value='';
 add(m,'user');
 const r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:m})});
 const d=await r.json();
 add(d.reply||'Réponse indisponible');
}
