
Serveur IA Chat Xeben.

La clé IA doit rester ici côté serveur.
Créer une route /api/chat qui appelle le fournisseur IA.
Ne jamais mettre la clé dans public/app.js.
